#define AppName "My Assisstant"
#define AppVersion "0.1.0"
[Setup]
AppId={{2F3BB52A-5854-44E4-873D-2D4BFC035F01}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=My Assisstant
DefaultDirName={localappdata}\Programs\My Assisstant
DefaultGroupName=My Assisstant
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=dist\setup
OutputBaseFilename=MyAssisstant_Setup
SetupIconFile=assets\app.ico
UninstallDisplayIcon={app}\MyAssisstant.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked
Name: "startup"; Description: "Start My Assisstant when I sign in"; Flags: unchecked
[Files]
Source: "dist\app\MyAssisstant\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\My Assisstant"; Filename: "{app}\MyAssisstant.exe"
Name: "{autodesktop}\My Assisstant"; Filename: "{app}\MyAssisstant.exe"; Tasks: desktopicon
[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "MyAssisstant"; ValueData: """{app}\MyAssisstant.exe"""; Flags: uninsdeletevalue; Tasks: startup
[Run]
Filename: "{app}\MyAssisstant.exe"; Description: "Launch My Assisstant"; Flags: nowait postinstall skipifsilent
