# My Assisstant — Windows voice and text companion

Version 0.1.0 — original implementation based on the supplied architecture and requested redesign.
This is a SOURCE PROJECT, not a precompiled or Windows-tested release. No .exe is included.
The app name deliberately uses the requested spelling: "My Assisstant".

## Included
- PySide6 desktop app for Windows x64.
- Minimal vector-icon HUD: hover expansion, drag-to-left/right docking, timed edge auto-hide.
- Non-activating HUD so editor focus stays in the target app.
- Dictation from a chosen microphone; real input-level waveform; maximum 120 seconds per recording.
- Google speech recognition through SpeechRecognition, with optional local spoken-punctuation replacement.
- Selected-text translation through an unofficial Google Translate endpoint and an editable RTL-capable result window.
- Edge read-aloud with decoded playback-buffer waveform, or offline installed Windows SAPI voices.
- Local SQLite notes, search, copy, save-as-new, read-aloud and confirmed deletion.
- Dark/light appearance, reduced-motion mode, microphone and language settings.
- Tray menu, global shortcuts and single-instance handling.
- Original app branding, PNG sizes, SVG source and Windows multi-resolution ICO.
- PyInstaller portable builder, Inno Setup installer recipe and GitHub Actions workflow.

## What is not claimed
This is not Wispr Flow or Grammarly; it is not affiliated with them.
No unlimited endpoint access, latency, RAM use, binary size or reliability is guaranteed.
There is no LLM/AI rewrite feature, no automatic input-field detection, and no browser extension.
Translation/read-aloud controls work on explicitly selected text, not arbitrary invisible page content.
The offline SAPI voice uses the installed default voice; it has no decoded-buffer waveform and does not auto-select the configured online language.
Qt playback waveform extraction is implemented but must be verified on real Windows audio devices.

## Build locally on Windows
1. Install 64-bit Python 3.12 (include the Python launcher).
2. Install Inno Setup 6 from https://jrsoftware.org/isinfo.php.
3. Extract this entire project into a writable folder.
4. Double-click BUILD_WINDOWS.cmd. It creates a virtual environment, installs dependencies, runs tests and builds both packages.
5. Expected outputs:
   - dist/portable/MyAssisstant_Portable.exe
   - dist/setup/MyAssisstant_Setup.exe

Portable only: run BUILD_WINDOWS.cmd --portable-only from a terminal.
For source mode, double-click RUN_SOURCE.cmd. Python and internet access for dependency installation are required.
The packaged app does not require the user to install Python.

## Build without using your local PC
Create a GitHub repository, upload the contents of this project INCLUDING the hidden .github folder,
then open Actions -> Build Windows portable and setup -> Run workflow.
After a successful run, download the MyAssisstant-Windows-x64 artifact.
That artifact contains the two actual .exe files. This workflow has NOT been run by the assistant.
GitHub Actions availability, permissions and billing limits depend on your account.

## First run and privacy
Cloud services are OFF and auto-paste is OFF until explicitly enabled in Settings & privacy.
Dictation/translation need cloud consent. Read-aloud can use installed Windows SAPI voices offline.
When enabled, recorded audio goes to Google, translated text goes to Google, and online read-aloud text goes to Microsoft's Edge speech service.
Do not send secrets or sensitive regulated data. Consumer/unofficial endpoints may change, deny requests or rate-limit you.
No API keys are embedded in this project; SpeechRecognition manages its own default consumer client behavior.
Raw microphone audio remains in memory until recognition completes. It is not written to the notes database.
Only explicitly saved notes are stored locally. Generated read-aloud MP3 files are temporary and deleted on normal completion/exit.
A crash or abrupt power loss may leave a MyAssisstant-*.mp3 file in the Windows temporary folder; delete these if necessary.
Provider-side retention is governed by the providers, not this app.
Notes/settings are plain local files, not encrypted. Logs store task error types, not dictation text.

## Clipboard and insertion safety
Auto-paste only runs when the original captured window is still foreground. Otherwise a result window opens.
The result window's Insert button intentionally returns focus to the captured target window when you click it.
Checking a window handle cannot guarantee the same field/caret remains selected; verify the destination before dictating.
Clipboard selection capture preserves UNICODE TEXT ONLY, not rich text, images, file lists or all clipboard formats.
Auto-paste intentionally leaves the dictated text on your clipboard.
Elevated applications, secure desktops, password fields and applications that reject synthetic keyboard events may not work.
Use Copy/manual paste as the fallback. The app does not request administrator rights.

## Shortcuts
Ctrl+Alt+Space: start/stop dictation
Alt+T: translate selected text
Alt+S: read selected text / stop
Alt+N: notes
Alt+H: show/hide HUD
Right-click HUD: menu
Drag HUD: dock at nearest screen side
Stop while recording finishes and transcribes; stop while processing cancels the displayed result, but an already submitted remote request cannot be recalled.
Hotkeys can conflict with other apps; remapping is not included in this version.

## Data locations
Installed/source mode: %APPDATA%\MyAssisstant
Portable mode: MyAssisstantData folder next to MyAssisstant_Portable.exe (requires writable folder).
Uninstall keeps your personal notes/settings. Delete the data folder manually if you want to remove them.
Do not run installed and portable copies simultaneously: they share a single-instance lock.

## Release validation
See WINDOWS_TEST_CHECKLIST.md. Static checks and core unit tests are separate from GUI/audio testing.
Build dependencies have bounded ranges, not a verified lockfile; review/pin exact versions after your first successful Windows build.
Unsigned executables can trigger Windows reputation warnings. Do not disable security software; review the source and sign your own releases for distribution.

## Branding
Original purple rounded-square speech-wave emblem with a small teal status dot.
app.ico contains 16, 24, 32, 48, 64, 128 and 256 pixel sizes.
This is a Windows app icon, NOT Microsoft's Windows trademark logo.
Source is in assets/logo.svg and PNG artwork in assets/.

## License
Application source and original artwork: MIT, see LICENSE.
Third-party libraries/services retain their own licenses and terms. This license does not grant usage rights for external services.
