import math
import tempfile
import unittest
from core.logic import clean_text, normalized_level, safe_insertion_target
from core.storage import Config, Notes

class LogicTests(unittest.TestCase):
    def test_punctuation(self):
        self.assertEqual(clean_text("Hello comma world question mark"), "Hello, world?")
    def test_arabic_preserved(self):
        self.assertEqual(clean_text("مرحبا بالعالم", "ar-SA"), "مرحبا بالعالم")
    def test_no_filler_deletion(self):
        self.assertEqual(clean_text("I mean what I said"), "I mean what I said")
    def test_levels(self):
        self.assertEqual(normalized_level(0), 0)
        self.assertEqual(normalized_level(float("nan")), 0)
        self.assertGreater(normalized_level(0.1), normalized_level(0.01))
        self.assertEqual(normalized_level(1), 1)
    def test_insertion_guard(self):
        self.assertTrue(safe_insertion_target(40,40))
        self.assertFalse(safe_insertion_target(40,41))
        self.assertFalse(safe_insertion_target(0,0))

class StorageTests(unittest.TestCase):
    def test_default_privacy(self):
        with tempfile.TemporaryDirectory() as temp:
            config = Config(temp)
            self.assertFalse(config.data["cloud"])
            self.assertFalse(config.data["auto_paste"])
            config.data["target"] = "en"; config.save()
            self.assertEqual(Config(temp).data["target"], "en")
    def test_bad_json(self):
        with tempfile.TemporaryDirectory() as temp:
            from pathlib import Path
            Path(temp, "settings.json").write_text("broken", encoding="utf-8")
            self.assertFalse(Config(temp).data["cloud"])
    def test_notes_unicode_and_delete(self):
        with tempfile.TemporaryDirectory() as temp:
            db = Notes(temp); db.add("مرحبا بالعالم"); db.add("hello world")
            rows = db.items("مرحبا"); self.assertEqual(len(rows), 1)
            db.delete(rows[0][0]); self.assertEqual(len(db.items()), 1); db.close()
    def test_sql_parameterization(self):
        with tempfile.TemporaryDirectory() as temp:
            db = Notes(temp); db.add("'); DROP TABLE notes; --")
            self.assertEqual(len(db.items()), 1); db.close()

if __name__ == "__main__": unittest.main()
