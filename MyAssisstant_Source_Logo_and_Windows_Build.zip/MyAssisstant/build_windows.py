import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def run(*args):
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--portable-only", action="store_true")
    args = parser.parse_args()
    if sys.platform != "win32" or platform.machine().lower() not in ("amd64", "x86_64"):
        raise SystemExit("Build on Windows x64 with 64-bit Python 3.12.")
    if sys.version_info[:2] != (3, 12):
        raise SystemExit("Use Python 3.12 for this project's selected build baseline.")
    common = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--windowed",
              "--icon", str(ROOT / "assets/app.ico"), "--add-data", str(ROOT / "assets") + ";assets",
              "--collect-all", "sounddevice", "--collect-all", "edge_tts",
              "--collect-all", "speech_recognition",
              "--hidden-import", "pynput.keyboard._win32", "--hidden-import", "win32com.client",
              "--hidden-import", "pythoncom", "--hidden-import", "PySide6.QtMultimedia",
              "--exclude-module", "torch", "--exclude-module", "tensorflow",
              "--exclude-module", "matplotlib", "--exclude-module", "pandas",
              "--version-file", "version_info.txt"]
    run(*common, "--onefile", "--name", "MyAssisstant_Portable", "--distpath", "dist/portable",
        "--workpath", "build/portable", "--specpath", "build", "main.py")
    portable = ROOT / "dist/portable/MyAssisstant_Portable.exe"
    if not portable.exists() or portable.stat().st_size == 0: raise SystemExit("Portable build missing.")
    if args.portable_only: return
    run(*common, "--onedir", "--name", "MyAssisstant", "--distpath", "dist/app",
        "--workpath", "build/installed", "--specpath", "build", "main.py")
    candidates = [shutil.which("ISCC"), os.getenv("ISCC_PATH"),
                  r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe", r"C:\Program Files\Inno Setup 6\ISCC.exe"]
    compiler = next((p for p in candidates if p and Path(p).is_file()), None)
    if not compiler:
        raise SystemExit("Portable EXE built. Install Inno Setup 6, then run build_windows.py again to build Setup.")
    run(compiler, "installer.iss")
    setup = ROOT / "dist/setup/MyAssisstant_Setup.exe"
    if not setup.exists() or setup.stat().st_size == 0: raise SystemExit("Setup build missing.")
    print("Built:", portable, "and", setup)

if __name__ == "__main__": main()
