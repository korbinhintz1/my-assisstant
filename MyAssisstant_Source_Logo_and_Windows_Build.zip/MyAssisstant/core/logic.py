import math
import re

def clean_text(text, language="en-US"):
    text = text.strip()
    if language.startswith("en"):
        commands = [("new paragraph", "\n\n"), ("new line", "\n"),
                    ("question mark", "?"), ("exclamation mark", "!"),
                    ("full stop", "."), ("comma", ","), ("semicolon", ";")]
        for spoken, mark in commands:
            text = re.sub(r"\b" + spoken + r"\b", lambda _: mark, text, flags=re.I)
    text = re.sub(r"[ \t]+([,.!?;:])", r"\1", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()

def normalized_level(rms):
    if not math.isfinite(rms) or rms <= 0.003:
        return 0.0
    return max(0.0, min(1.0, (20 * math.log10(rms) + 50) / 42))

def safe_insertion_target(expected, current):
    return bool(expected and expected == current)
