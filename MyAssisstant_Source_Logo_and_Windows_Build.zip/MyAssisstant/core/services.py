import asyncio
import threading
import time
import numpy as np
import requests
import sounddevice as sd
import speech_recognition as sr
import edge_tts
from core.logic import normalized_level

LANGUAGES = {"English": "en-US", "Arabic": "ar-SA", "French": "fr-FR",
             "Spanish": "es-ES", "German": "de-DE", "Chinese": "zh-CN", "Japanese": "ja-JP"}
TARGETS = {"Arabic": "ar", "English": "en", "French": "fr", "Spanish": "es",
           "German": "de", "Chinese": "zh-CN", "Japanese": "ja"}
VOICES = {"en": "en-US-JennyNeural", "ar": "ar-EG-SalmaNeural", "fr": "fr-FR-DeniseNeural",
          "es": "es-ES-ElviraNeural", "de": "de-DE-KatjaNeural", "zh": "zh-CN-XiaoxiaoNeural", "ja": "ja-JP-NanamiNeural"}

class Recorder:
    def __init__(self, level_callback):
        self.level_callback = level_callback
        self.stream = None
        self.chunks = []
        self.frames = 0
        self.error = False
        self.limit_reached = False
        self.rate = 16000
    def start(self, device=None):
        self.chunks = []
        self.frames = 0
        self.error = False
        self.limit_reached = False
        info = sd.query_devices(device, "input")
        self.rate = int(info["default_samplerate"])
        def receive(indata, frames, timing, status):
            if status:
                self.error = True
            if self.frames < self.rate * 120:
                self.chunks.append(indata.copy())
                self.frames += frames
            else:
                self.limit_reached = True
            rms = float(np.sqrt(np.mean(indata.astype(np.float32) ** 2)))
            self.level_callback(normalized_level(rms))
        self.stream = sd.InputStream(device=device, samplerate=self.rate, channels=1,
                                     dtype="float32", blocksize=max(256, self.rate // 25), callback=receive)
        self.stream.start()
    def stop(self):
        stream, self.stream = self.stream, None
        if stream:
            stream.stop()
            stream.close()
        if not self.chunks:
            raise RuntimeError("No microphone audio was captured.")
        samples = np.concatenate(self.chunks).reshape(-1)
        self.chunks = []
        if samples.size < self.rate // 4 or float(np.sqrt(np.mean(samples ** 2))) < 0.003:
            raise RuntimeError("No clear speech detected. Check your microphone.")
        return (np.clip(samples, -1, 1) * 32767).astype("<i2").tobytes(), self.rate
    def close(self):
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.chunks = []

def recognize(pcm, rate, language):
    recognizer = sr.Recognizer()
    recognizer.operation_timeout = 20
    try:
        return recognizer.recognize_google(sr.AudioData(pcm, rate, 2), language=language)
    except sr.UnknownValueError:
        raise RuntimeError("Speech was not understood. Please try a shorter recording.") from None
    except sr.RequestError:
        raise RuntimeError("Speech service unavailable. Check your connection and try again.") from None

def translate(text, target):
    if len(text) > 5000:
        raise RuntimeError("Translate selections of 5,000 characters or fewer.")
    try:
        response = requests.get("https://translate.googleapis.com/translate_a/single",
            params={"client": "gtx", "sl": "auto", "tl": target, "dt": "t", "q": text}, timeout=(5, 15))
        response.raise_for_status()
        obj = response.json()
        result = "".join(part[0] for part in obj[0] if part and part[0])
        return result, obj[2] or "auto"
    except (requests.RequestException, ValueError, IndexError, TypeError, KeyError):
        raise RuntimeError("Translation service unavailable. This unofficial endpoint can change or be rate-limited.") from None

def edge_audio(text, language, path):
    if len(text) > 12000:
        raise RuntimeError("Read-aloud selections must be 12,000 characters or fewer.")
    voice = VOICES.get(language.split("-")[0], VOICES["en"])
    async def run():
        await asyncio.wait_for(edge_tts.Communicate(text, voice).save(str(path)), timeout=45)
    try:
        asyncio.run(run())
    except Exception:
        raise RuntimeError("Online read-aloud unavailable. Disable cloud services to use installed Windows voices.") from None

def sapi_speak(text, stop_event):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        voice = win32com.client.Dispatch("SAPI.SpVoice")
        voice.Speak(text, 1)
        while not voice.WaitUntilDone(50):
            pythoncom.PumpWaitingMessages()
            if stop_event.is_set():
                voice.Speak("", 3)
                break
    finally:
        pythoncom.CoUninitialize()
