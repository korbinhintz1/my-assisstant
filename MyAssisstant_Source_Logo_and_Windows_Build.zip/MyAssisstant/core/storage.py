import json
import os
import sqlite3
import sys
from pathlib import Path

DEFAULTS = dict(cloud=False, auto_paste=False, language="en-US", target="ar",
                edge_hide=True, reduced_motion=False, theme="dark", x=None, y=None,
                dock="right", polish=True, mic=None)

def data_directory():
    portable = getattr(sys, "frozen", False) and "portable" in Path(sys.executable).stem.lower()
    if portable:
        path = Path(sys.executable).parent / "MyAssisstantData"
    else:
        path = Path(os.getenv("APPDATA", str(Path.home()))) / "MyAssisstant"
    path.mkdir(parents=True, exist_ok=True)
    return path

class Config:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory is not None else data_directory()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "settings.json"
        self.first_run = not self.path.exists()
        self.data = DEFAULTS.copy()
        try:
            obj = json.loads(self.path.read_text(encoding="utf-8"))
            self.data.update({k: v for k, v in obj.items() if k in DEFAULTS})
        except (OSError, ValueError, TypeError, AttributeError):
            pass
    def save(self):
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

class Notes:
    def __init__(self, directory):
        self.db = sqlite3.connect(str(Path(directory) / "notes.db"))
        self.db.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, body TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP)")
        self.db.commit()
    def add(self, body):
        if body.strip():
            self.db.execute("INSERT INTO notes(body) VALUES(?)", (body,))
            self.db.commit()
    def items(self, query=""):
        return self.db.execute("SELECT id,body,created FROM notes WHERE body LIKE ? ORDER BY id DESC", ("%" + query + "%",)).fetchall()
    def delete(self, note_id):
        self.db.execute("DELETE FROM notes WHERE id=?", (note_id,))
        self.db.commit()
    def close(self):
        self.db.close()
