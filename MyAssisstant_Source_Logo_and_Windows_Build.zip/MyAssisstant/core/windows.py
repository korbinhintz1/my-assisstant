import ctypes
import time
import uuid
import win32clipboard as clip
import win32con
import win32gui
from core.logic import safe_insertion_target

user32 = ctypes.windll.user32

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_size_t)]
class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_size_t)]
class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong), ("wParamL", ctypes.c_ushort), ("wParamH", ctypes.c_ushort)]
class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]
class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", ctypes.c_ulong), ("u", INPUTUNION)]
user32.SendInput.argtypes = [ctypes.c_uint, ctypes.POINTER(INPUT), ctypes.c_int]
user32.SendInput.restype = ctypes.c_uint

def foreground():
    return win32gui.GetForegroundWindow()

def nonactivating(hwnd):
    style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
    win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE,
                          style | win32con.WS_EX_NOACTIVATE | win32con.WS_EX_TOOLWINDOW)
    win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0,
                         win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_NOACTIVATE)

def _clipboard(fn):
    for i in range(8):
        try:
            clip.OpenClipboard()
        except Exception:
            time.sleep(0.02 * (i + 1))
            continue
        try:
            return fn()
        finally:
            clip.CloseClipboard()
    raise RuntimeError("Clipboard is busy. Please try again.")

def read_text():
    def read():
        return clip.GetClipboardData(win32con.CF_UNICODETEXT) if clip.IsClipboardFormatAvailable(win32con.CF_UNICODETEXT) else ""
    return _clipboard(read)

def write_text(text):
    def write():
        clip.EmptyClipboard()
        clip.SetClipboardData(win32con.CF_UNICODETEXT, text)
    _clipboard(write)

def wait_modifiers():
    for _ in range(100):
        if not any(user32.GetAsyncKeyState(k) & 0x8000 for k in (0x10, 0x11, 0x12, 0x5B, 0x5C)):
            return
        time.sleep(0.02)
    raise RuntimeError("Release Ctrl, Alt, Shift and Windows keys, then try again.")

def chord(key, expected, cancelled=None):
    wait_modifiers()
    if not safe_insertion_target(expected, foreground()):
        raise RuntimeError("The target window changed. Text is available in the result window.")
    if cancelled and cancelled():
        return False
    values = [(0x11, 0), (key, 0), (key, 2), (0x11, 2)]
    events = (INPUT * 4)(*[INPUT(type=1, ki=KEYBDINPUT(wVk=k, dwFlags=f)) for k, f in values])
    if user32.SendInput(4, events, ctypes.sizeof(INPUT)) != 4:
        raise RuntimeError("Windows blocked text insertion. Use Copy and paste manually.")
    return True

def capture_selection(expected):
    wait_modifiers()
    if foreground() != expected:
        raise RuntimeError("Select text in your target app and try again.")
    old = read_text()
    marker = "my-assisstant-selection-" + uuid.uuid4().hex
    write_text(marker)
    new = marker
    try:
        chord(0x43, expected)
        for _ in range(30):
            time.sleep(0.025)
            new = read_text()
            if new != marker:
                break
        if new == marker or not new.strip():
            raise RuntimeError("No selected text was copied. Highlight text and try again.")
        return new
    finally:
        if read_text() in (marker, new):
            write_text(old)

def paste(text, expected, cancelled=None):
    wait_modifiers()
    if (cancelled and cancelled()) or not safe_insertion_target(expected, foreground()):
        return False
    write_text(text)
    return chord(0x56, expected, cancelled)
