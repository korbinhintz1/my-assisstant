# Windows release checklist — NOT EXECUTED IN THIS ENVIRONMENT

## Build
- [ ] Build on clean Windows x64 / Python 3.12.
- [ ] Confirm Windows import smoke test and core unit tests pass.
- [ ] Confirm both PE executables build and launch.
- [ ] Portable runs on a PC without Python; settings persist next to executable.
- [ ] Setup installs per-user without requesting admin; shortcuts and uninstaller work.
- [ ] Optional startup is off by default and is removed during uninstall.
- [ ] Startup and portable cold-start times measured (no target promised).

## HUD
- [ ] Left/right docking and edge-tab hover at 100%, 125%, 150% and 200% scaling.
- [ ] Multi-monitor arrangement including negative coordinates.
- [ ] Monitor disconnected while app is running (recovery may require restarting).
- [ ] Overlay buttons do not steal focus in Word, Notepad, browser and VS Code.
- [ ] Dark/light theme and reduced motion.
- [ ] Hide/show shortcut, tray restore, second-instance restore.
- [ ] No click-through bugs near screen edge, no unwanted idle animation.

## Audio
- [ ] Default and explicitly selected microphones at differing device sample rates.
- [ ] Permission denied, missing device, unplugged device and no speech produce clear feedback.
- [ ] Waveform responds to real microphone samples and settles in silence.
- [ ] Two-minute cap automatically ends recording.
- [ ] English and Arabic dictation, no internet, provider failure/timeouts.
- [ ] Edge read-aloud returns audio; waveform tracks decoded audio buffers.
- [ ] Offline SAPI voice works and stop cancels it; no fake waveform in offline mode.
- [ ] Audio output device changed; repeated playback; cancellation during synthesis.

## Text / safety
- [ ] Cloud consent defaults off; no cloud requests while disabled.
- [ ] Auto-paste defaults off; original foreground window guard works.
- [ ] Wrong-window switch during recognition never auto-pastes.
- [ ] Modifier-key wait and clipboard retries.
- [ ] Translation handles English->Arabic and RTL output.
- [ ] Empty selection, clipboard lock, elevated target, target window closed.
- [ ] Insertion via explicit button restores intended target; check caret and field.
- [ ] SQLite notes: add, search, Unicode, copy, delete confirmation.
- [ ] No transcript/selection content in logs.
- [ ] Temporary MP3 deletion on normal finish and exit.

## Distribution
- [ ] Review external service terms and data policy for intended use.
- [ ] Pin tested dependency versions; audit dependencies.
- [ ] Scan binaries and obtain code-signing certificate if distributing publicly.
- [ ] Save build SHA-256 hashes; document GUI/audio test results.
