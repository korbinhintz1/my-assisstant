from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
 QPlainTextEdit, QCheckBox, QComboBox, QFormLayout, QLineEdit, QListWidget, QListWidgetItem,
 QMessageBox, QDialogButtonBox, QGroupBox)
import sounddevice as sd
from core.services import LANGUAGES, TARGETS

STYLE = """
QWidget { background: #191922; color: #ededf5; font-family: 'Segoe UI'; font-size: 13px; }
QDialog { background: #191922; }
QPushButton { background: #2c2b38; border: 1px solid #3d3b4d; border-radius: 8px; padding: 8px 14px; }
QPushButton:hover { background: #3b374e; border-color: #8a7cff; }
QPushButton:pressed { background: #4d4566; }
QPushButton:disabled { color: #777482; }
QLineEdit, QPlainTextEdit, QListWidget, QComboBox { background: #22222e; border: 1px solid #393847; border-radius: 8px; padding: 8px; selection-background-color: #6356c5; }
QComboBox QAbstractItemView { background: #22222e; color: #ededf5; selection-background-color: #6356c5; }
QCheckBox { spacing: 8px; padding: 4px; }
QGroupBox { border: 1px solid #393847; border-radius: 8px; margin-top: 14px; padding: 14px; }
QGroupBox::title { subcontrol-origin: margin; left: 14px; }
QLabel#heading { font-size: 22px; font-weight: 600; }
"""
LIGHT_STYLE = STYLE.replace("#191922", "#f8f8fc").replace("#ededf5", "#242434").replace("#2c2b38", "#ececf4").replace("#22222e", "#ffffff").replace("#393847", "#dcdce8").replace("#3d3b4d", "#dcdce8").replace("#3b374e", "#e4e1f7").replace("#4d4566", "#d9d4f3")

def style(dialog, config):
    dialog.setStyleSheet(LIGHT_STYLE if config.data["theme"] == "light" else STYLE)

def button(text, fn):
    b = QPushButton(text); b.clicked.connect(fn); return b

class SettingsWindow(QDialog):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("My Assisstant — Settings & privacy"); self.setMinimumWidth(540)
        style(self, config)
        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,24); layout.setSpacing(16)
        title = QLabel("My Assisstant"); title.setObjectName("heading"); layout.addWidget(title)
        privacy = QLabel("Cloud dictation sends microphone audio to Google. Translation sends selected text to Google. Online read-aloud sends text to Microsoft's Edge speech service. These consumer/unofficial services can fail or be rate-limited. Do not send confidential information. Cloud services are OFF until you enable them.")
        privacy.setWordWrap(True); layout.addWidget(privacy)
        self.cloud = QCheckBox("I consent to enable cloud speech, translation and read-aloud")
        self.cloud.setChecked(config.data["cloud"]); layout.addWidget(self.cloud)
        self.paste = QCheckBox("Automatically paste dictation into the original app if it is still focused")
        self.paste.setChecked(config.data["auto_paste"]); layout.addWidget(self.paste)
        form = QFormLayout(); layout.addLayout(form)
        self.lang = QComboBox()
        for name, code in LANGUAGES.items(): self.lang.addItem(name, code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(config.data["language"])))
        form.addRow("Dictation / online voice language", self.lang)
        self.target = QComboBox()
        for name, code in TARGETS.items(): self.target.addItem(name, code)
        self.target.setCurrentIndex(max(0, self.target.findData(config.data["target"])))
        form.addRow("Translate into", self.target)
        self.mic = QComboBox(); self.mic.addItem("Windows default microphone", None)
        try:
            for i, device in enumerate(sd.query_devices()):
                if device["max_input_channels"]: self.mic.addItem(device["name"], i)
        except Exception: pass
        self.mic.setCurrentIndex(max(0, self.mic.findData(config.data["mic"])))
        form.addRow("Microphone", self.mic)
        self.theme = QComboBox(); self.theme.addItem("Dark", "dark"); self.theme.addItem("Light", "light")
        self.theme.setCurrentIndex(max(0, self.theme.findData(config.data["theme"])))
        form.addRow("Appearance", self.theme)
        self.edge = QCheckBox("Auto-hide as a small screen-edge tab"); self.edge.setChecked(config.data["edge_hide"])
        self.motion = QCheckBox("Reduce animation"); self.motion.setChecked(config.data["reduced_motion"])
        self.polish = QCheckBox("Replace spoken English punctuation commands (local rules, not AI)"); self.polish.setChecked(config.data["polish"])
        for box in (self.edge, self.motion, self.polish): layout.addWidget(box)
        tip = QLabel("Ctrl+Alt+Space  Dictate / stop\nAlt+T  Translate selection   ·   Alt+S  Read selection / stop\nAlt+N  Notes   ·   Alt+H  Hide / show overlay\nDrag the overlay to either side. Right-click for the menu.")
        tip.setWordWrap(True); layout.addWidget(tip)
        controls = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        controls.accepted.connect(self.accept); controls.rejected.connect(self.reject); layout.addWidget(controls)
    def values(self):
        return dict(cloud=self.cloud.isChecked(), auto_paste=self.paste.isChecked(),
                    language=self.lang.currentData(), target=self.target.currentData(), mic=self.mic.currentData(),
                    theme=self.theme.currentData(), edge_hide=self.edge.isChecked(), reduced_motion=self.motion.isChecked(), polish=self.polish.isChecked())

class ResultWindow(QDialog):
    copy_requested = Signal(str)
    insert_requested = Signal(str, int)
    speak_requested = Signal(str)
    save_requested = Signal(str)
    def __init__(self, config):
        super().__init__()
        self.setWindowTitle("My Assisstant — Result"); self.resize(540, 460); style(self, config)
        self.target_hwnd = 0
        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,24); layout.setSpacing(12)
        self.title = QLabel("Result"); self.title.setObjectName("heading"); layout.addWidget(self.title)
        self.subtitle = QLabel(); self.subtitle.setWordWrap(True); layout.addWidget(self.subtitle)
        self.original = QPlainTextEdit(); self.original.setReadOnly(True); self.original.setMaximumHeight(110); layout.addWidget(self.original)
        self.output = QPlainTextEdit(); layout.addWidget(self.output)
        row = QHBoxLayout(); layout.addLayout(row)
        row.addWidget(button("Copy", lambda: self.copy_requested.emit(self.output.toPlainText())))
        row.addWidget(button("Insert", lambda: self.insert_requested.emit(self.output.toPlainText(), self.target_hwnd)))
        row.addWidget(button("Listen", lambda: self.speak_requested.emit(self.output.toPlainText())))
        row.addWidget(button("Save note", lambda: self.save_requested.emit(self.output.toPlainText())))
    def present(self, text, title, target_hwnd=0, original="", target_language="en"):
        self.title.setText(title); self.target_hwnd = target_hwnd
        self.subtitle.setText("Edit, copy, or insert into the captured target app. Insert returns focus only when you click it.")
        self.original.setPlainText(original); self.original.setVisible(bool(original))
        self.output.setPlainText(text)
        rtl = target_language.split("-")[0] in ("ar", "he", "fa", "ur")
        self.output.setLayoutDirection(Qt.LayoutDirection.RightToLeft if rtl else Qt.LayoutDirection.LeftToRight)
        self.show(); self.raise_(); self.activateWindow()

class NotesPanel(QDialog):
    copy_requested = Signal(str)
    speak_requested = Signal(str)
    def __init__(self, db, config):
        super().__init__(); self.db = db
        self.setWindowTitle("My Assisstant — Notes"); self.resize(630, 530); style(self, config)
        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,24); layout.setSpacing(12)
        title = QLabel("Your notes"); title.setObjectName("heading"); layout.addWidget(title)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search saved notes…"); layout.addWidget(self.search)
        self.list = QListWidget(); self.list.setMaximumHeight(170); layout.addWidget(self.list)
        self.editor = QPlainTextEdit(); self.editor.setPlaceholderText("Write a new note, or select a saved note…"); layout.addWidget(self.editor)
        row = QHBoxLayout(); layout.addLayout(row)
        row.addWidget(button("New", lambda: self.editor.clear()))
        row.addWidget(button("Save as new", self.save))
        row.addWidget(button("Copy", lambda: self.copy_requested.emit(self.editor.toPlainText())))
        row.addWidget(button("Listen", lambda: self.speak_requested.emit(self.editor.toPlainText())))
        row.addWidget(button("Delete", self.delete))
        self.search.textChanged.connect(self.refresh)
        self.list.currentItemChanged.connect(self.select)
        self.refresh()
    def refresh(self, *_):
        self.list.clear()
        for note_id, body, created in self.db.items(self.search.text()):
            item = QListWidgetItem(created + "  ·  " + body.replace("\n", " ")[:70])
            item.setData(Qt.ItemDataRole.UserRole, (note_id, body)); self.list.addItem(item)
    def select(self, item, previous):
        if item: self.editor.setPlainText(item.data(Qt.ItemDataRole.UserRole)[1])
    def save(self):
        self.db.add(self.editor.toPlainText()); self.refresh()
    def delete(self):
        item = self.list.currentItem()
        if item and QMessageBox.question(self, "Delete note", "Permanently delete this saved note?") == QMessageBox.StandardButton.Yes:
            self.db.delete(item.data(Qt.ItemDataRole.UserRole)[0]); self.editor.clear(); self.refresh()
