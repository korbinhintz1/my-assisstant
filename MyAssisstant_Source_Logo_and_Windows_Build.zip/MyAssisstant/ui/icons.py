from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainterPath, QPen

def glyph(p, name, rect, color="#f4f4fa"):
    p.save()
    p.translate(rect.center())
    scale = min(rect.width(), rect.height()) / 24
    p.scale(scale, scale)
    p.setPen(QPen(QColor(color), 1.65, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.setBrush(Qt.BrushStyle.NoBrush)
    if name == "mic":
        p.drawRoundedRect(QRectF(-3.5, -9, 7, 12), 3.5, 3.5)
        path = QPainterPath(QPointF(-6.5, -1))
        path.cubicTo(-6.5, 8, 6.5, 8, 6.5, -1)
        p.drawPath(path)
        p.drawLine(QPointF(0, 6), QPointF(0, 10))
        p.drawLine(QPointF(-3, 10), QPointF(3, 10))
    elif name == "stop":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(color))
        p.drawRoundedRect(QRectF(-5, -5, 10, 10), 2, 2)
    elif name == "translate":
        p.drawLine(QPointF(-9, -5), QPointF(2, -5))
        p.drawLine(QPointF(-4, -9), QPointF(-4, -5))
        path = QPainterPath(QPointF(0, -5)); path.quadTo(-1, 2, -8, 5); p.drawPath(path)
        path = QPainterPath(QPointF(-7, -3)); path.quadTo(-4, 2, 0, 5); p.drawPath(path)
        p.drawLine(QPointF(1, 8), QPointF(5, -2))
        p.drawLine(QPointF(5, -2), QPointF(9, 8))
        p.drawLine(QPointF(3, 4), QPointF(7, 4))
    elif name == "speak":
        path = QPainterPath(QPointF(-9, -3)); path.lineTo(-5, -3); path.lineTo(0, -7)
        path.lineTo(0, 7); path.lineTo(-5, 3); path.lineTo(-9, 3); path.closeSubpath(); p.drawPath(path)
        p.drawArc(QRectF(0, -5, 9, 10), -65 * 16, 130 * 16)
        p.drawArc(QRectF(-1, -8, 16, 16), -55 * 16, 110 * 16)
    elif name == "more":
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(color))
        for x in (-6, 0, 6): p.drawEllipse(QPointF(x, 0), 1.4, 1.4)
    elif name == "check":
        path = QPainterPath(QPointF(-7, 0)); path.lineTo(-2, 5); path.lineTo(8, -6); p.drawPath(path)
    elif name == "close":
        p.drawLine(QPointF(-5, -5), QPointF(5, 5)); p.drawLine(QPointF(5, -5), QPointF(-5, 5))
    elif name == "brand":
        for i, h in enumerate((5, 11, 17, 11, 5)):
            x = -8 + i * 4
            p.drawLine(QPointF(x, -h/2), QPointF(x, h/2))
    p.restore()
