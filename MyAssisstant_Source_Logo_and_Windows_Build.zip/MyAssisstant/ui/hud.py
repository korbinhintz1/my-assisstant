import ctypes
import math
from PySide6.QtCore import Qt, QTimer, QRectF, Signal, QPoint, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QPainter, QColor, QPen, QCursor
from PySide6.QtWidgets import QWidget, QApplication
from core.windows import nonactivating
from ui.icons import glyph

class OverlayPillWindow(QWidget):
    action = Signal(str)
    position_saved = Signal(int, int, str)
    def __init__(self, config):
        super().__init__(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.config = config
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setMouseTracking(True)
        self.setWindowTitle("My Assisstant")
        self.mode = "idle"
        self.expanded = False
        self.tucked = False
        self.level = self.target_level = 0.0
        self.phase = 0.0
        self.hover = ""
        self.regions = {}
        self.dragging = False
        self.press_global = None
        self.dock = config.data.get("dock", "right")
        self.animation = QPropertyAnimation(self, b"geometry", self)
        self.animation.setDuration(150)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.tuck_timer = QTimer(self); self.tuck_timer.setSingleShot(True)
        self.tuck_timer.timeout.connect(self.tuck)
        self.leave_timer = QTimer(self); self.leave_timer.setSingleShot(True)
        self.leave_timer.timeout.connect(self.collapse)
        self.hover_timer = QTimer(self); self.hover_timer.setSingleShot(True)
        self.hover_timer.timeout.connect(self.expand)
        self.tick = QTimer(self); self.tick.setInterval(33); self.tick.timeout.connect(self.advance)
        self.resize(56, 56)
        screen = QApplication.primaryScreen().availableGeometry()
        x, y = config.data.get("x"), config.data.get("y")
        self.move(int(x) if x is not None else screen.right() - 64,
                  int(y) if y is not None else screen.center().y())
        self.snap(animate=False)
        self.setToolTip("My Assisstant · hover for controls\nCtrl+Alt+Space: dictate")
    def showEvent(self, event):
        super().showEvent(event)
        nonactivating(int(self.winId()))
        self.tuck_timer.start(2500)
    def nativeEvent(self, kind, message):
        class MSG(ctypes.Structure):
            _fields_ = [("hwnd", ctypes.c_void_p), ("message", ctypes.c_uint),
                        ("wParam", ctypes.c_size_t), ("lParam", ctypes.c_ssize_t),
                        ("time", ctypes.c_ulong), ("pt", ctypes.c_long * 2)]
        msg = MSG.from_address(int(message))
        if msg.message == 0x0021:
            return True, 3
        return super().nativeEvent(kind, message)
    def screen_rect(self):
        screen = QApplication.screenAt(self.geometry().center()) or QApplication.primaryScreen()
        return screen.availableGeometry()
    def snap(self, animate=True):
        rect = self.screen_rect()
        width = 204 if self.expanded and self.mode == "idle" else (178 if self.expanded else 56)
        height = 56
        visible = 20 if self.tucked else width + 8
        x = rect.right() - visible + 1 if self.dock == "right" else rect.left() + visible - width
        y = max(rect.top() + 8, min(self.y(), rect.bottom() - height - 8))
        target = self.geometry(); target.setRect(x, y, width, height)
        self.animation.stop()
        if animate and not self.config.data["reduced_motion"] and self.isVisible():
            self.animation.setStartValue(self.geometry()); self.animation.setEndValue(target); self.animation.start()
        else:
            self.setGeometry(target)
        self.update()
    def expand(self):
        if not self.isVisible() or self.dragging: return
        self.tuck_timer.stop(); self.leave_timer.stop()
        self.expanded = True; self.tucked = False; self.snap()
    def collapse(self):
        if self.mode != "idle" or self.dragging: return
        if self.geometry().contains(QCursor.pos()): return
        self.expanded = False; self.tucked = False; self.snap()
        self.tuck_timer.start(2200)
    def tuck(self):
        if self.mode != "idle" or self.dragging or self.geometry().contains(QCursor.pos()): return
        if self.config.data["edge_hide"]:
            self.expanded = False; self.tucked = True; self.snap()
    def set_mode(self, mode):
        self.mode = mode; self.level = self.target_level = 0
        if mode == "idle":
            self.tick.stop(); self.expanded = True; self.snap(); self.leave_timer.start(1600)
        else:
            self.expand()
            if not self.config.data["reduced_motion"]: self.tick.start()
        self.update()
    def set_level(self, value):
        self.target_level = max(0.0, min(1.0, float(value)))
        if self.config.data["reduced_motion"]:
            self.level = self.target_level; self.update()
    def advance(self):
        factor = 0.58 if self.target_level > self.level else 0.17
        self.level += (self.target_level - self.level) * factor
        self.target_level *= 0.92
        self.phase += 0.18
        self.update()
    def enterEvent(self, event):
        self.leave_timer.stop(); self.tuck_timer.stop(); self.hover_timer.start(180)
        super().enterEvent(event)
    def leaveEvent(self, event):
        self.hover_timer.stop(); self.hover = ""; self.update(); self.leave_timer.start(900)
        super().leaveEvent(event)
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.action.emit("menu"); return
        if event.button() == Qt.MouseButton.LeftButton:
            self.press_global = event.globalPosition().toPoint()
            self.start_pos = self.pos(); self.dragging = False
            self.pressed = self.hit(event.position())
    def mouseMoveEvent(self, event):
        self.hover = self.hit(event.position()); self.update()
        if self.press_global is not None and event.buttons() & Qt.MouseButton.LeftButton:
            delta = event.globalPosition().toPoint() - self.press_global
            if delta.manhattanLength() > 6:
                self.dragging = True; self.animation.stop(); self.tuck_timer.stop(); self.hover_timer.stop()
                self.move(self.start_pos + delta)
    def mouseReleaseEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton: return
        if self.dragging:
            rect = self.screen_rect()
            self.dock = "right" if self.geometry().center().x() >= rect.center().x() else "left"
            self.tucked = False; self.snap(False)
            self.position_saved.emit(self.x(), self.y(), self.dock)
        elif self.press_global is not None:
            name = self.hit(event.position())
            if name and name == self.pressed: self.action.emit(name)
            elif not self.expanded: self.expand()
        self.press_global = None; self.dragging = False
    def hit(self, point):
        return next((name for name, rect in self.regions.items() if rect.contains(point)), "")
    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        light = self.config.data["theme"] == "light"
        foreground = "#242434" if light else "#f4f4fa"
        background = QColor("#f7f7fc" if light else "#191922"); background.setAlpha(249)
        body = QRectF(6, 6, self.width() - 12, self.height() - 12)
        for i in range(4, 0, -1):
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(0, 0, 0, 5 + i))
            p.drawRoundedRect(body.adjusted(-i, -i + 1, i, i + 1), 18 + i, 18 + i)
        p.setPen(QPen(QColor("#dcdce8" if light else "#373743"), 1)); p.setBrush(background)
        p.drawRoundedRect(body, 18, 18)
        self.regions = {}
        if not self.expanded:
            glyph(p, "brand", QRectF(16, 16, 24, 24), "#8a7cff")
            return
        if self.mode == "idle":
            for i, name in enumerate(("mic", "translate", "speak", "menu")):
                rect = QRectF(16 + i * 44, 11, 36, 34)
                self.regions[name] = rect
                if self.hover == name:
                    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("#e9e7ff" if light else "#323040"))
                    p.drawRoundedRect(rect, 10, 10)
                glyph(p, "more" if name == "menu" else name, rect.adjusted(6, 5, -6, -5),
                      "#8a7cff" if name == "mic" else foreground)
        else:
            indicator = QRectF(18, 17, 22, 22)
            if self.mode == "busy":
                p.setPen(QPen(QColor("#8a7cff"), 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                p.setBrush(Qt.BrushStyle.NoBrush)
                start = 90 if self.config.data["reduced_motion"] else int(self.phase * 100) % 360
                p.drawArc(indicator, start * 16, 240 * 16)
            else:
                glyph(p, "mic" if self.mode == "listening" else "speak", indicator, "#8a7cff")
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("#8a7cff"))
            for i, weight in enumerate((0.30, 0.64, 0.9, 1.0, 0.9, 0.64, 0.30)):
                height = 3 + 22 * self.level * weight
                p.drawRoundedRect(QRectF(56 + i * 7, 28 - height/2, 3, height), 1.5, 1.5)
            rect = QRectF(128, 11, 36, 34); self.regions["stop"] = rect
            if self.hover == "stop":
                p.setBrush(QColor("#ebe9f3" if light else "#33313c")); p.drawRoundedRect(rect, 10, 10)
            glyph(p, "stop", rect.adjusted(6, 5, -6, -5), foreground)
