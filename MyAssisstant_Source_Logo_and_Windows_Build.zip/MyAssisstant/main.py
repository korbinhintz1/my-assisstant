import sys
if sys.platform != "win32":
    raise SystemExit("My Assisstant is a Windows desktop application. Build and run on Windows x64.")
import logging
import tempfile
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from pynput import keyboard
from PySide6.QtCore import QObject, Signal, QTimer, Qt, QUrl
from PySide6.QtGui import QAction, QIcon, QCursor
from PySide6.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QMessageBox
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput, QAudioBufferOutput, QAudioFormat
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from core.storage import Config, Notes
from core.logic import clean_text, normalized_level
from core import windows as win
from core.services import Recorder, recognize, translate, edge_audio, sapi_speak
from ui.hud import OverlayPillWindow
from ui.windows import SettingsWindow, ResultWindow, NotesPanel, style

APP_NAME = "My Assisstant"
VERSION = "0.1.0"

def asset(name):
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / "assets" / name

class Bridge(QObject):
    action = Signal(str)
    level = Signal(float)
    done = Signal(int, str, object)
    failed = Signal(int, str)

class Assistant(QObject):
    def __init__(self, app, config):
        super().__init__(); self.app = app; self.config = config
        self.bridge = Bridge(); self.pool = ThreadPoolExecutor(max_workers=3)
        self.token = 0; self.state = "idle"; self.target = 0; self.closed = False
        self.audio_files = set(); self.sapi_stop = threading.Event()
        self.db = Notes(config.directory)
        self.hud = OverlayPillWindow(config); self.hud.setWindowIcon(app.windowIcon())
        self.results = ResultWindow(config); self.notes = NotesPanel(self.db, config)
        self.recorder = Recorder(self.bridge.level.emit)
        self.player = QMediaPlayer(self); self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio); self.audio.setVolume(0.85)
        self.buffers = QAudioBufferOutput(self)
        self.player.setAudioBufferOutput(self.buffers)
        self.buffers.audioBufferReceived.connect(self.playback_level)
        self.player.mediaStatusChanged.connect(self.media_status)
        self.player.errorOccurred.connect(self.media_error)
        self.bridge.action.connect(self.dispatch, Qt.ConnectionType.QueuedConnection)
        self.bridge.level.connect(self.hud.set_level, Qt.ConnectionType.QueuedConnection)
        self.bridge.done.connect(self.finished, Qt.ConnectionType.QueuedConnection)
        self.bridge.failed.connect(self.failed, Qt.ConnectionType.QueuedConnection)
        self.hud.action.connect(self.dispatch)
        self.hud.position_saved.connect(self.save_position)
        for window in (self.results, self.notes):
            window.copy_requested.connect(self.copy)
            window.speak_requested.connect(self.read_text)
        self.results.insert_requested.connect(self.insert)
        self.results.save_requested.connect(self.save_note)
        self.tray = QSystemTrayIcon(app.windowIcon(), self); self.tray.setToolTip(APP_NAME)
        self.menu = QMenu(); self.menu.setStyleSheet("QMenu { padding:6px; } QMenu::item { padding:7px 18px; }")
        for title, action in [("Dictate / stop   Ctrl+Alt+Space", "mic"), ("Translate selection   Alt+T", "translate"),
                              ("Read selection / stop   Alt+S", "speak"), ("Notes   Alt+N", "notes"),
                              ("Show / hide overlay   Alt+H", "toggle"), ("Settings & privacy", "settings"),
                              ("About", "about"), ("Quit", "quit")]:
            item = QAction(title, self.menu); item.triggered.connect(lambda checked=False, a=action: self.dispatch(a)); self.menu.addAction(item)
        self.tray.setContextMenu(self.menu); self.tray.activated.connect(self.tray_clicked); self.tray.show()
        self.timer = QTimer(self); self.timer.setInterval(500); self.timer.timeout.connect(self.check_limit); self.timer.start()
        self.hotkeys = None
        try:
            mapping = {"<ctrl>+<alt>+<space>": "mic", "<alt>+t": "translate", "<alt>+s": "speak",
                       "<alt>+n": "notes", "<alt>+h": "toggle"}
            self.hotkeys = keyboard.GlobalHotKeys({key: (lambda a=action: self.bridge.action.emit(a)) for key, action in mapping.items()})
            self.hotkeys.start()
        except Exception:
            QTimer.singleShot(500, lambda: self.notice("Hotkeys unavailable. Use the overlay or tray controls."))
        self.hud.show()
        if config.first_run: QTimer.singleShot(700, self.settings)
        self.app.aboutToQuit.connect(self.shutdown)
    def save_position(self, x, y, dock):
        self.config.data.update(x=x, y=y, dock=dock); self.config.save()
    def tray_clicked(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger: self.dispatch("toggle")
    def notice(self, message):
        self.tray.showMessage(APP_NAME, message, QSystemTrayIcon.MessageIcon.Information, 5000)
    def dispatch(self, action):
        if self.closed: return
        if action == "mic": self.dictate()
        elif action == "translate": self.selection("translate")
        elif action == "speak":
            if self.state in ("speaking", "synthesizing"): self.stop()
            else: self.selection("speak")
        elif action == "stop":
            if self.state == "listening": self.dictate()
            else: self.stop()
        elif action == "notes":
            if self.notes.isVisible(): self.notes.hide()
            else: self.notes.refresh(); self.notes.show(); self.notes.raise_(); self.notes.activateWindow()
        elif action == "settings": self.settings()
        elif action == "toggle":
            if self.hud.isVisible(): self.hud.hide()
            else: self.hud.show(); self.hud.expand()
        elif action == "menu": self.menu.popup(QCursor.pos())
        elif action == "about":
            QMessageBox.information(None, APP_NAME,
                f"{APP_NAME} {VERSION}\nIndependent Windows dictation, translation and read-aloud companion.\nOriginal logo and UI. Not affiliated with Wispr, Grammarly, Apple, Google or Microsoft.\nCloud services are optional and not guaranteed. No AI rewriting is included.\nSource release: Windows build/testing still required.")
        elif action == "quit": self.app.quit()
    def settings(self):
        if self.state != "idle": self.notice("Stop the current task before changing settings."); return
        dialog = SettingsWindow(self.config)
        if dialog.exec():
            self.config.data.update(dialog.values()); self.config.save()
            self.hud.snap(); self.hud.update(); style(self.results, self.config); style(self.notes, self.config)
    def cloud_allowed(self):
        if self.config.data["cloud"]: return True
        self.notice("Cloud services are disabled. Enable them in Settings & privacy to dictate or translate.")
        return False
    def set_state(self, state):
        self.state = state
        self.hud.set_mode("listening" if state == "listening" else "speaking" if state == "speaking" else "idle" if state == "idle" else "busy")
        self.tray.setToolTip(APP_NAME + " — " + state)
    def submit(self, kind, fn):
        token = self.token
        def run():
            try:
                result = fn()
                if not self.closed: self.bridge.done.emit(token, kind, result)
            except Exception as error:
                logging.warning("Task failed: %s", type(error).__name__)
                if not self.closed:
                    message = str(error) if isinstance(error, RuntimeError) else "The operation failed. Check your microphone, Windows permissions and internet connection."
                    self.bridge.failed.emit(token, message)
        self.pool.submit(run)
    def dictate(self):
        if self.state == "listening":
            try: pcm, rate = self.recorder.stop()
            except Exception as error:
                self.set_state("idle"); self.notice(str(error)); return
            language = self.config.data["language"]; polish = self.config.data["polish"]
            target = self.target; auto_paste = self.config.data["auto_paste"]; job = self.token
            self.set_state("transcribing")
            def work():
                text = recognize(pcm, rate, language)
                if polish: text = clean_text(text, language)
                pasted = win.paste(text, target, lambda: self.closed or job != self.token) if auto_paste else False
                return dict(text=text, pasted=pasted, target=target, language=language)
            self.submit("dictation", work)
            return
        if self.state != "idle": self.notice("Stop the current task first."); return
        if not self.cloud_allowed(): return
        self.target = win.foreground(); self.token += 1
        try:
            self.recorder.start(self.config.data["mic"])
            self.set_state("listening")
        except Exception:
            self.recorder.close(); self.set_state("idle")
            self.notice("Cannot open the microphone. Check Windows microphone permissions and your selected input device.")
    def check_limit(self):
        if self.state == "listening" and self.recorder.limit_reached:
            self.notice("Two-minute recording limit reached; processing your recording."); self.dictate()
    def selection(self, kind):
        if self.state != "idle": self.notice("Stop the current task first."); return
        if kind == "translate" and not self.cloud_allowed(): return
        target = win.foreground(); self.target = target; self.token += 1
        language = self.config.data["target"]
        self.set_state("copying")
        def work():
            original = win.capture_selection(target)
            if kind == "translate":
                text, detected = translate(original, language)
                return dict(text=text, original=original, target=target, language=language, detected=detected)
            return original
        self.submit(kind, work)
    def finished(self, token, kind, value):
        if token != self.token or self.closed: return
        if kind == "dictation":
            self.set_state("idle")
            if value["pasted"]: self.notice("Dictation inserted. The text remains on your clipboard.")
            else: self.results.present(value["text"], "Dictation", value["target"], target_language=value["language"])
        elif kind == "translate":
            self.set_state("idle")
            self.results.present(value["text"], "Translation", value["target"], value["original"], value["language"])
        elif kind == "speak":
            self.set_state("idle"); self.read_text(value)
        elif kind == "audio":
            self.set_state("speaking"); self.player.setSource(QUrl.fromLocalFile(str(value))); self.player.play()
        elif kind == "sapi": self.set_state("idle")
        elif kind == "insert":
            self.set_state("idle")
            if not value: self.notice("Target app changed. Use Copy and paste into the desired field.")
    def failed(self, token, message):
        if token != self.token or self.closed: return
        self.set_state("idle"); self.notice(message); self.cleanup_audio()
    def read_text(self, text):
        if self.state != "idle": self.notice("Stop the current task first."); return
        if not text.strip(): return
        if len(text) > 12000: self.notice("Read-aloud selections must be 12,000 characters or fewer."); return
        self.token += 1
        if self.config.data["cloud"]:
            self.set_state("synthesizing")
            path = Path(tempfile.gettempdir()) / ("MyAssisstant-" + uuid.uuid4().hex + ".mp3")
            self.audio_files.add(path); language = self.config.data["language"]; job = self.token
            def work():
                try:
                    edge_audio(text, language, path)
                    return path
                finally:
                    if self.closed or job != self.token:
                        try: path.unlink(missing_ok=True)
                        except OSError: pass
            self.submit("audio", work)
        else:
            self.sapi_stop = threading.Event(); event = self.sapi_stop
            self.set_state("speaking"); self.notice("Using an installed Windows voice. Playback waveform is unavailable in this offline mode.")
            self.submit("sapi", lambda: sapi_speak(text, event))
    def playback_level(self, buffer):
        if self.state != "speaking" or not buffer.isValid() or buffer.byteCount() == 0: return
        try:
            fmt = buffer.format().sampleFormat()
            mapping = {QAudioFormat.SampleFormat.Float: (np.float32, 1.0),
                       QAudioFormat.SampleFormat.Int16: (np.int16, 32768.0),
                       QAudioFormat.SampleFormat.Int32: (np.int32, 2147483648.0),
                       QAudioFormat.SampleFormat.UInt8: (np.uint8, 128.0)}
            dtype, scale = mapping[fmt]
            values = np.frombuffer(buffer.constData(), dtype=dtype, count=buffer.byteCount() // np.dtype(dtype).itemsize).astype(np.float32)
            if fmt == QAudioFormat.SampleFormat.UInt8: values -= 128
            values /= scale
            self.hud.set_level(normalized_level(float(np.sqrt(np.mean(values ** 2)))))
        except (TypeError, ValueError, KeyError):
            self.hud.set_level(0)
    def media_status(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia and self.state == "speaking":
            self.player.setSource(QUrl()); self.set_state("idle"); self.cleanup_audio()
    def media_error(self, error, message):
        if error != QMediaPlayer.Error.NoError and self.state == "speaking":
            self.stop(); self.notice("Audio playback failed. Check your Windows output device.")
    def cleanup_audio(self):
        for path in list(self.audio_files):
            try: path.unlink(missing_ok=True); self.audio_files.discard(path)
            except OSError: pass
    def stop(self):
        self.token += 1; self.sapi_stop.set(); self.recorder.close()
        self.player.stop(); self.player.setSource(QUrl()); self.set_state("idle"); self.cleanup_audio()
    def copy(self, text):
        try: win.write_text(text); self.notice("Copied.")
        except RuntimeError as error: self.notice(str(error))
    def insert(self, text, target):
        if self.state != "idle": self.notice("Stop the current task first."); return
        if not target or not text.strip(): self.notice("No captured target app. Use Copy instead."); return
        self.results.hide()
        try:
            import win32gui
            if not win32gui.IsWindow(target): raise RuntimeError("The original target window is closed. Use Copy instead.")
            win32gui.SetForegroundWindow(target)
        except Exception:
            self.results.show(); self.notice("Windows would not restore the target. Use Copy instead."); return
        self.token += 1; job = self.token; self.set_state("inserting")
        self.submit("insert", lambda: win.paste(text, target, lambda: self.closed or job != self.token))
    def save_note(self, text):
        self.db.add(text); self.notes.refresh(); self.notice("Saved locally.")
    def shutdown(self):
        if self.closed: return
        self.closed = True; self.token += 1; self.sapi_stop.set(); self.timer.stop()
        if self.hotkeys: self.hotkeys.stop()
        self.recorder.close(); self.player.stop(); self.player.setSource(QUrl())
        self.cleanup_audio(); self.pool.shutdown(wait=False, cancel_futures=True)
        self.config.save(); self.db.close(); self.tray.hide()

def main():
    app = QApplication(sys.argv); app.setApplicationName(APP_NAME); app.setApplicationVersion(VERSION)
    app.setQuitOnLastWindowClosed(False); app.setWindowIcon(QIcon(str(asset("app.ico"))))
    probe = QLocalSocket(); probe.connectToServer("MyAssisstant-single-instance-v1")
    if probe.waitForConnected(250):
        probe.write(b"show"); probe.flush(); probe.waitForBytesWritten(300)
        return 0
    QLocalServer.removeServer("MyAssisstant-single-instance-v1")
    server = QLocalServer(); server.listen("MyAssisstant-single-instance-v1")
    try: config = Config()
    except OSError:
        QMessageBox.critical(None, APP_NAME, "Cannot create the settings folder. Move the portable EXE to a writable folder."); return 1
    logging.basicConfig(filename=str(config.directory / "app.log"), level=logging.WARNING,
                        format="%(asctime)s %(levelname)s %(message)s")
    def error_handler(kind, value, tb):
        logging.error("Unhandled exception: %s", kind.__name__)
        QMessageBox.critical(None, APP_NAME, "An unexpected error occurred. Restart My Assisstant; details are limited in the local log.")
    sys.excepthook = error_handler
    assistant = Assistant(app, config)
    def new_connection():
        socket = server.nextPendingConnection()
        if socket:
            socket.disconnectFromServer(); socket.deleteLater()
        assistant.hud.show(); assistant.hud.expand()
    server.newConnection.connect(new_connection)
    code = app.exec(); server.close(); return code

if __name__ == "__main__":
    raise SystemExit(main())
